<?php 
include 'connection.php';
session_start();

if(isset($_POST['btn-search'])){
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $sql = mysqli_query($connect, "SELECT * FROM `user` WHERE email = '$email'") or die('field query');
    if(mysqli_num_rows($sql) > 0){
        $row = mysqli_fetch_assoc($sql);
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['first'] = $row['first_name'];
        $_SESSION['last'] = $row['last_name'];
       $_SESSION['picture'] = $row['image'];
        header('Location: find_account.php');
    }else{
        $message[] = 'You Have no Data';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forgot.css">
    <title>forgot page</title>
</head>
<body>
    <div class="container">
        <form action="" method="post" enctype="multipart/form-data" class="form-box">
    
       <div class="wrapper">
        <div class="header-search">
            <h3>Find your account</h3>
        </div>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo '<div class="message"><p>'.$message.'</p></div>';
         }
      }
      ?>
        <div class="guide-search">
            <p>Please enter your email to search for your account.</p>
        </div>
        <div class="wrapper-box">
            <input type="email" placeholder="Email" name="email" class="box" required>
        </div>
        <div class="btn-submit">
            <div class="btn-box">
            <button type="button" class="box" id="btn"><a href="login.php">Cancel</a></button>
            <input type="submit" value="Search" name="btn-search" class="box">
        </div>
        </div>

        
       </div> 
    </form>
    </div>
</body>
</html>