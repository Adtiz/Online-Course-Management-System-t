<?php 
include "connection.php";
session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
    header('location:login.php');
 };
 
 if(isset($_GET['logout'])){
   unset($user_ID);
    session_destroy();
    header('location:login.php');
 }

 if(isset($_POST['user_update'])){
      $user_fname = $_POST['first_name'];
      $user_lname = $_POST['last_name'];
      $user_email = $_POST['email'];
      
     $sql = "UPDATE `user` SET first_name = '$user_fname', last_name = '$user_lname',email = '$user_email' WHERE id = '$user_ID'";
     $query = mysqli_query($connect, $sql);

     $user_image = $_FILES['update_image']['name'];
      $user_image_size = $_FILES['update_image']['size'];
      $user_image_tmp = $_FILES['update_image']['tmp_name'];
     $user_image_folder = 'user_profile/'. $user_image;
     if(!empty($user_image)){
        if($user_image_size > 2000000){
         echo '<script>alert("image too large!");</script>'; 
        }else{
           $image_update_query = mysqli_query($connect, "UPDATE `user` SET image = '$user_image' WHERE id = '$user_ID'") or die('query failed');
           if($image_update_query && $query){
              move_uploaded_file($user_image_tmp, $user_image_folder);
              echo '<script>alert("updated succssfully (:");</script>';   
           }  
        }
     }

 }

 if(isset($_GET['delete_user'])){
    $ID = $_GET['delete_user']; 
    $sql = "DELETE FROM `user` WHERE id = $ID";
    $query = mysqli_query($connect, $sql);
    header("Location: login.php");

 }
 function Data(){
    global $connect;
    $deps = $_SESSION['course_department'];
    $sql = "SELECT COUNT(department) AS count FROM `course` WHERE department = '$deps' ";
    $query = mysqli_query($connect, $sql);
    
    if($row = mysqli_fetch_assoc($query)){
        return   $row['count'];
    }else{
        return 0;
    }
   
 }
 
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Online Course System</title>
</head>
<body>
    <div class="container-box">
        <nav class="nav-top">
            <a href=""><h3><i class="ri-graduation-cap-fill"></i>OCS</h3></a>
            <div class="title-name">
                <h2>Dashboard</h2>
            </div>
            <div class="profile-user">
            <?php 

$sql = "SELECT * FROM `user` WHERE id = '$user_ID'";
$query = mysqli_query($connect, $sql);
$row = mysqli_fetch_assoc($query);
if($row['image'] === ""):?>
<img src="user_profile/default-profile.jpg" alt="" onclick="Myprofile();">
<?php else:?>
<img src="user_profile/<?php echo $row['image']; ?>" alt="" onclick="Myprofile();">
<?php endif?> 
<a href="dashboard.php?logout=<?php echo $row['id']; ?>"><p>Logout</p></a>
            </div>
        </nav>


<div class="row">


    <div class="amount-box">


        <div class="department-box box">
           <a href="course.php">
            <p>Course : 
            <?php 
    $query = mysqli_query($connect, "SELECT COUNT(*) AS count FROM  `course` ");
     if($row = mysqli_fetch_assoc($query)){
        echo $row['count'];
     }else{
        echo '0';
     }
    ?>
            </p>
           </a> 
        </div>
        <div class="course-box box">
            <a href="department.php">
                <p>
                Department : <?php 
    $query = mysqli_query($connect, "SELECT COUNT(*) AS count FROM  `department` ");
     if($row = mysqli_fetch_assoc($query)){
        echo $row['count'];
     }else{
        echo '0';
     }
    ?>
            </p>
            </a>
        </div>
        
        </div>


    <div class="department-row dep">
      <h3>Department</h3>
      <div class="department-list">
<?php
   $query = mysqli_query($connect, "SELECT * FROM `department`");
   while($row = mysqli_fetch_assoc($query)){
  $_SESSION['course_department'] = $row['department_acronym'];
  $name_department = $_SESSION['course_department'];
?>
        <div class="department">
            <?php 
            if($row['department_logo'] == ""):
            ?>
            <img src="dep_logo/default.png" alt="">
            <?php else:?>
                <img src="dep_logo/<?php echo $row['department_logo'] ?>" alt="">
            <?php 
            endif
            ?>
            <div class="department-name">
                  <h2><?php echo $_SESSION['course_department'];?></h2>
                  <p><?php echo $row['department_name'];?></p>
                   
                  <div class="dep-btn">
                    <a href="display.php?viewID=<?php echo $row['id'];?>"><i class="ri-gallery-view-2"></i></a>
                    <p>Course Data : <?php echo Data();  ?> </p>
                  </div>
                   
                </div>  
            
        </div>
<?php }?>

      </div>

    </div>





    
    <div class="account-user form" >
        
           <form action="" method="post" enctype="multipart/form-data">
            <i class="ri-close-fill" onclick="Cancel();"></i>
            <h4>Profile</h4>
            
              <div class="profile-pic">
              <?php 

$sql = "SELECT * FROM `user` WHERE id = '$user_ID'";
$query = mysqli_query($connect, $sql);
$row = mysqli_fetch_assoc($query);
if($row['image'] === ""):?>
<img src="user_profile/default-profile.jpg" alt="">
<?php else:?>
<img src="user_profile/<?php echo $row['image']; ?>" alt="">
<?php endif?> 


                <div class="img-box" id="box">
                    <input type="file" name="update_image" accept="image/jpg, image/jpeg, image/png">
                       <i class="ri-camera-fill"></i>
                 </div>
              </div>

              <div class="input-box">
                <div class="input">
                    <label for=""> First Name</label>
                    <input type="text" name="first_name" value="<?php echo $row['first_name']; ?>">
                </div>
                <div class="input">
                    <label for=""> Last Name</label>
                    <input type="text" name="last_name" value="<?php echo $row['last_name']; ?>">
                </div>
            </div>
            <div class="account-box">
                <div class="input">
                    <label for="">Email</label>
                    <input type="email" name="email" value="<?php echo $row['email']; ?>">
                </div>
  
            </div>
            <div class="btn-UD">
                <button type="submit" name="user_update">Update</button>
                <a href="dashboard.php?delete_user=<?php echo $row['id']; ?>"><button type="button">Delete</button></a>
              </div>
           </form>
        </div>
</div>
        
    </div>
    <script>


function Myprofile(){
     document.querySelector('.account-user').style.top = "0";

}
function Cancel(){
    document.querySelector('.account-user').style.top = "-50em";

}


    </script>
</body>
</html>