<?php
include 'connection.php';
session_start();
$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
};

if(isset($_POST['btn-search'])){
    $password = mysqli_real_escape_string($connect, md5($_POST['password']));
    $query = mysqli_query($connect, "UPDATE `user` SET password = '$password' WHERE id = '$user_id'") or die('query failed');
    if($query){
        $message[] = 'Success Change password';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forgot.css">
    <title>Chage Password</title>

<body>
<head>

</head>
<div class="container">
    <form action="" method="post" enctype="multipart/form-data" class="form-container">
       <div class="wrapper">
       <?php
         $select = mysqli_query($connect, "SELECT * FROM `user` WHERE id = '$user_id'") or die('query failed');
         if(mysqli_num_rows($select) > 0){
            $fetch = mysqli_fetch_assoc($select);
         }
         if($fetch['image'] == ''){
            echo '<img src="user_prolife/default-profile.jpg">';
         }else{
            echo '<img src="user_profile/'.$fetch['image'].'">';
         }
      ?>

        <h3>
       <?php echo $_SESSION['first'],'&nbsp;', $_SESSION['last']; ?></h3>
        <div class="email">
            <?php
        echo $_SESSION['email'];
        ?>
        </div>
        <?php
                  if(isset($message)){
                    foreach($message as $message){
                       echo '<div class="pop-pop">'.$message.'</div>';
                    }
                 }
      ?>
        <div class="wrapper-box">
            <input type="password" placeholder="new password" name="password" class="box">
        </div>
        <div class="btn-sub">
            <input type="submit" value="Submit" name="btn-search" class="box">           
             <button type="submit" class="box" id="btn"><a href="login.php">Log in</a></button>
        </div>
       </div> 
    </form>
</div>

</body>
</html>