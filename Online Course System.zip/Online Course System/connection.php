<?php
$connect = mysqli_connect("localhost: 3306", "root", "", "online_course_system");


?>