<?php
include "connection.php";
session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
  unset($user_ID);
   session_destroy();
   header('location:login.php');
}


$department_name = "";
$department_acronym = "";
$bool = false;


if(isset($_POST['addDep'])){

    $department_name = $_POST['name'];
    $department_acronym = $_POST['acronym'];
    $add_image = $_FILES['logo_image']['name'];
    $add_image_size = $_FILES['logo_image']['size'];
    $add_image_tmp = $_FILES['logo_image']['tmp_name'];
    $add_image_folder = 'dep_logo/'. $add_image;
    
   $sql = "INSERT INTO `department`(department_acronym, department_name, department_logo) VALUES ('$department_acronym', '$department_name', '$add_image')";
   $query = mysqli_query($connect, $sql);

         if($query){
            move_uploaded_file($add_image_tmp, $add_image_folder);
            $message[] = '<div class="message" style="border: 2px solid green; padding: 13px; margin-top: 20px; background-color: #a9dcb5; color: #fff;"> Successfully Add Department </div>';
               
         }else{
            echo '<script>alert("Check your query or data!");</script>';
         }
      


}



if(isset($_GET['updateID'])){
    $Id = $_GET['updateID'];
    $bool = true;
    $sql = "SELECT * FROM `department` WHERE id = $Id";
    $query = mysqli_query($connect, $sql) or die(mysqli_error($connect));
   $row = mysqli_fetch_assoc($query);
    $department_logo = $row['department_logo'];
    $department_name = $row['department_name'];
    $department_acronym = $row['department_acronym'];
    
}
if(isset($_POST['update'])){
    $department_acronym = $_POST['acronym'];
    $department_name = $_POST['name'];
    $dep_image = $_FILES['logo_image']['name'];
    $dep_image_size = $_FILES['logo_image']['size'];
    $dep_image_tmp = $_FILES['logo_image']['tmp_name'];
    $dep_image_folder = 'dep_logo/'. $dep_image;

    $sql = "UPDATE `department` SET department_acronym = '$department_acronym', department_name = '$department_name', department_logo = '$dep_image' WHERE id = '$Id'";
    $query = mysqli_query($connect, $sql) or die(mysqli_error($connect));

         if($query){
            move_uploaded_file($dep_image_tmp, $dep_image_folder);
            $message[] = '<div class="message" style="border: 2px solid green; padding: 13px; margin-top: 20px; background-color: #a9dcb5; color: #fff;"> Successfully Update Department </div>';
             
         }else{
            echo '<script>alert("Check your query or data!");</script>'; 
         }  
      }
   

if(isset($_GET['deleteID'])){
    $ID = $_GET['deleteID']; 
    $sql = "DELETE FROM `department` WHERE id = $ID";
    $query = mysqli_query($connect, $sql);
    
  echo '<script>alert("Success Remove Department List! ");</script>';

 }
?>
  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Department Course</title>
</head>
<body>
    <div class="container-box">
        <nav class="nav-top">
            <a href=""><h3><i class="ri-graduation-cap-fill"></i>OCS</h3></a>
            <div class="title-name">
                <h2> Online Course Management
                System</h2>
            </div>
            <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="logout.php?logout=<?php echo $user_ID ?>">Logout</a></li>
            </ul>
        </nav>

<div class="container row">

<div class="form-box">

<?php
if($bool == false):
?>
    <form action="" method="post" enctype="multipart/form-data">
        <h3>Add Department</h3>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo $message;
         }
      }
      ?>
        <div class="img-logo">
            <img src="dep_logo/default.png" alt="">

            <div class="img-box" id="box">
                <input type="file" name="logo_image" accept="image/jpg, image/jpeg, image/png">
                   <i class="ri-camera-fill"></i>
             </div>
        </div>
        <div class="input-box">
            <div class="box" id="box">
                <label for="">Department Acronym</label>
                <input type="text" name="acronym" required>
            </div>

        </div>
      <div class="input-box">
        <div class="box">
            <label for="">Department Name</label>
            <textarea name="name" id="" required></textarea>
        </div>

      </div>
      <div class="btn-box">
        <button type="submit" name="addDep">ADD</button>
      </div>
    </form>

    <?php
else:
?>

 <form action="" method="post" enctype="multipart/form-data">
        <h3>Update Department</h3>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo $message;
         }
      }
      ?>
        <div class="img-logo">
            <?php 
            if($row['department_logo'] == ""):
            ?> 
            <img src="dep_logo/default.png" alt="">
            <?php else: ?>
            <img src="dep_logo/<?php  echo $department_logo; ?>" alt="">
            <?php 
            endif
            ?>
            <div class="img-box" id="box">
                <input type="file" name="logo_image" accept="image/jpg, image/jpeg, image/png">
                   <i class="ri-camera-fill"></i>
             </div>
        </div>
        <div class="input-box">
            <div class="box" id="box">
                <label for="">Department Acronym</label>
                <input type="text" name="acronym" value="<?php  echo $department_acronym; ?>" required>
            </div>

        </div>
      <div class="input-box">
        <div class="box">
            <label for="">Department Name</label>
            <textarea name="name" id="" required><?php  echo $department_name; ?></textarea>
        </div>
      </div>
      <div class="btn-box">
        <button type="submit" name="update">Update</button>
      </div>
    </form>


<?php
endif
?>

</div>

    <div class="table-box">
        <h3>List Department</h3>

        <div class="table-data">
            <table>
                <tr>
                    <th>Department ID</th>
                    <th>Department Acronym</th>
                    <th>Department Name</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
                 
                <?php 
        $_count = 1;        
    $query = mysqli_query($connect, "SELECT * FROM `department`");
    while($row = mysqli_fetch_assoc($query)){
    ?>

                <tr>
  
                    <td> <?php echo $_count; ?></td>
                    <td><?php echo $row['department_acronym']; ?></td>
                    <td><?php echo $row['department_name']; ?></td>
                    <td><a href="department.php?updateID=<?php echo $row['id']; ?>"><i class="ri-edit-line"></i></a></td>
                    <td><a href="department.php?deleteID=<?php echo $row['id']; ?>"><i class="ri-delete-bin-6-line"></i></a></i></td>
                </tr>
               <?php  
             $_count++;
            } ?>
            </table>
        </div>
    </div>


    
</div>



    </div>

</body>
</html>


    