<?php 
include 'connection.php';
session_start();

if(isset($_POST['btn-submit'])){


    $fname = mysqli_real_escape_string($connect, $_POST['firstname']);
    $lname = mysqli_real_escape_string($connect, $_POST['lastname']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $pass = mysqli_real_escape_string($connect, md5($_POST['npassword']));
    $cpass = mysqli_real_escape_string($connect, md5($_POST['cpassword']));
    $birth = mysqli_real_escape_string($connect, $_POST['birth']);
    $gender = mysqli_real_escape_string($connect, $_POST['gender']);

    $select = mysqli_query($connect, "SELECT * FROM `user` WHERE email = '$email' AND password = '$pass'") or die('query failed');
   
    if(mysqli_num_rows($select) > 0){
        $message[] = '<div class="alert"> user already exist'; 
     }else{
        if($pass != $cpass){
           $message[] = '<div class="alert"> confirm password not matched! </div>';
        }else{
           $insert = mysqli_query($connect, "INSERT INTO `user`(first_name, last_name, email, password, birth, gender) VALUES('$fname', '$lname','$email', '$pass', '$birth','$gender')") or die('query failed');
           if($insert){
              $message[] = '<div class="success" > registered successfully! </div>';
           }else{
              $message[] = '<div class="alert"> registeration failed! </div>';
           }
        }
     }
 }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="form.css">
    <title>Sign up</title>
</head>
<body>
  <div class="container">
  <form action="" method="post" enctype="multipart/form-data">
    <div class="register-account">
        <h3 class="register-create">Create a new account</h3>
        <p> it's quick and easy. </p>
    </div>
    <div class="wrapper">
    <?php
    if(isset($message)){
     foreach($message as $message){
        echo $message;
    }   
    }
    
      ?>
      
        <div class="wrapper-box">
            <input type="text" placeholder="First name" class="box" name="firstname" required/>
            <input type="text" placeholder="Last name" class="box" name="lastname" required/>
        </div>
    
    <div class="wrapper-email-pass">
    <input type="email" placeholder="ex.,email@gmail.com" class="box" name="email" required/>
    <input type="password" placeholder="New password" class="box" name="npassword" required/>
    <input type="password" placeholder="Confirm password" class="box" name="cpassword" required/>
    </div>

    <div class="birth_gen">
    <div class="wrapper-birth">
        <span>Birthday</span>
        <input type="date" name="birth" class="box">
    </div>
    <div class="wrapper-birth">
        <span>Gender </span>
        <div class="ctgr">
        <label for="1">         
            <input type="radio" name="gender" id="1" value="Male"/>
            <span>Male</span>
        </label>
        <label for="2">
            <input type="radio" name="gender" id="2" value="Female"/>
            <span>Female</span>
        </label>
        </div>
    </div>
    </div>
    <div class="concern-box">
        <p>People who use our service may have uploaded your information to Register.</p>
    </div>
    
    <div class="btn-box">
        <input type="submit" name="btn-submit" value="Sign Up" class="box">
    </div>
            <p>Already have an <a href="login.php">account?</a></p>
</div>
  </form>
  </div>
</body>
</html>