<?php
include 'connection.php';
session_start();

if(isset($_POST['btn-submit'])){

   $email = mysqli_real_escape_string($connect, $_POST['email']);
   $pass = mysqli_real_escape_string($connect, md5($_POST['password']));

   $select = mysqli_query($connect, "SELECT * FROM `user` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
      $row = mysqli_fetch_assoc($select);
      $_SESSION['user_id'] = $row['id'];
      $_SESSION['email'] = $row['email'];
      
      header('location: dashboard.php');

   }else{
      $message[] = 'incorrect email or password!';
   }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="form.css">
    <title>login page</title>
</head>
<body>
    <div class="container">

        <form action="" method="post" enctype="multipart/form-data" class="form-box">
        <h3 class="login">Login</h3>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo '<div class="message"><p>'.$message.'</p></div>';
         }
      }
      ?>
       
        <div class="wrapper">
        <div class="wrapper-email-pass">
    <input type="email" placeholder="ex.,email@gmail.com" class="box" name="email" required/>
    <input type="password" placeholder="New password" class="box" name="password" required/>
    </div>
    <div class="forgot-pass">
        <a href="forgot_search.php">
        Forgot password?
        </a>
    </div>
    <div class="btn-box">
        <input type="submit" name="btn-submit" value="Login" class="box">     
    </div>
    <p>don't have an account? <a href="register.php">regiser now</a></p>
</div>

        </form>
    </div>
</body>
</html>