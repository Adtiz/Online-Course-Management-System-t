<?php 
include "connection.php";
session_start();

$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
   header('location:login.php');
};

if(isset($_GET['logout'])){
  unset($user_ID);
   session_destroy();
   header('location:login.php');
}

$course_code = " ";
$course_acronym = " ";
$course_name = " ";
$course_department = " ";
$course_description = " ";
$bool = false;


if(isset($_POST['register_course'])){

    $course_code = $_POST['code'];
    $course_acronym = $_POST['acronym'];
    $course_name = $_POST['name'];
    $course_department = $_POST['department'];
    $course_description = $_POST['description'];
    $sql = "INSERT INTO `course`(course_code, course_acronym, course_name, course_description, department) VALUES ('$course_code','$course_acronym', '$course_name', '$course_description', '$course_department')";
    $query = mysqli_query($connect, $sql) or die(mysqli_error($connect));
        if($query){
            $message[] = '<div class="message" style="border: 2px solid green; padding: 13px; margin-top: 20px; background-color: #a9dcb5; color: #fff;"> Successfully Registered Course </div>';
    
        }else{
            echo '<script>alert("Check your data!")</script>';
        }
        
}




if(isset($_GET['update'])){
    $Id = $_GET['update'];
    $bool = true;
    $sql = "SELECT * FROM `course` WHERE course_id = $Id";
    $query = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($query);
   $course_ID = $row['course_id'];
    $course_code = $row['course_code'];
    $course_acronym = $row['course_acronym'];
    $course_name = $row['course_name'];
    $course_department = $row['department'];
    $course_description = $row['course_description'];
 
}
if(isset($_POST['update_course'])){

    $course_code = $_POST['code'];
    $course_acronym = $_POST['acronym'];
    $course_name = $_POST['name'];
    $course_department = $_POST['department'];
    $course_description = $_POST['description'];
    $sql = "UPDATE `course`SET course_code = '$course_code', course_acronym = '$course_acronym', course_name = '$course_name', course_description = '$course_description', department = '$course_department' WHERE course_id = '$Id'";
    $query = mysqli_query($connect, $sql) or die(mysqli_error($connect));
    if($query){
        $message[] = '<div class="message" style="border: 2px solid green; padding: 13px; margin-top: 20px; background-color: #a9dcb5; color: #fff;"> Successfully Update Course </div>';

    }else{
        echo '<script>alert("Check your data!")</script>';
    }
        
}

if(isset($_GET['deleteID'])){
    $ID = $_GET['deleteID']; 
    $sql = "DELETE FROM `course` WHERE id = $ID";
    $query = mysqli_query($connect, $sql);
     echo '<script>alert("Success Remove Course List! ");</script>';

 }

?>
    
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Department Course</title>
</head>
<body>
    <div class="container-box">
        <nav class="nav-top">
            <a href=""><h3><i class="ri-graduation-cap-fill"></i>OCS</h3></a>
            <div class="title-name">
            <h2> Online Course Management
            System</h2>
                
            </div>
            <ul>
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="logout.php?logout=<?php echo $user_ID ?>">Logout</a></li>
            </ul>
        </nav>

<div class="container row">

<div class="form-box">
<?php 
if($bool == false):
?>
    <form action="" method="post">
        <h3>Course Register</h3>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo $message;
         }
      }
      ?>
        <div class="input-box">
            <div class="box">
                <label for="">Course Code</label>
                <input type="text" name="code" required>
            </div>
            <div class="box">
                <label for="">Course Acronym</label>
                <input type="text" name="acronym" required>
            </div>
            <div class="box">
                <label for="">Course Department</label>
                <input type="text" name="department" required>
            </div>
        </div>
      <div class="input-box">
        <div class="box">
            <label for="">Course Name</label>
            <textarea name="name" id="" required></textarea>
        </div>
        <div class="box">
            <label for="">Course Description</label>
            <textarea name="description" id="" required></textarea>
        </div>
      </div>
      <div class="btn-box">
        <button type="submit" name="register_course">Register</button>
      </div>
    </form>
    <?php 
else:
?>
    <form action="" method="post">
        <h3>Course Register</h3>
        <?php
      if(isset($message)){
         foreach($message as $message){
            echo $message;
         }
      }
      ?>
        <div class="input-box">
            <div class="box">
                <label for="">Course Code</label>
                <input type="text" name="code" value="<?php echo $course_code ?>" required>
            </div>
            <div class="box">
                <label for="">Course Acronym</label>
                <input type="text" name="acronym" value="<?php echo $course_acronym ?>" required>
            </div>
            <div class="box">
                <label for="">Course Department</label>
                <input type="text" name="department" value="<?php echo $course_department ?>" required>
            </div>
        </div>
      <div class="input-box">
        <div class="box">
            <label for="">Course Name</label>
            <textarea name="name" id="" required> <?php echo $course_name ?></textarea>
        </div>
        <div class="box">
            <label for="">Course Description</label>
            <textarea name="description" id="" required> <?php echo $course_description ?></textarea>
        </div>
      </div>
      <div class="btn-box">
        <button type="submit" name="update_course">Update</button>
      </div>
    </form>
<?php 
endif
?>
</div>

    <div class="table-box">
        <h3>List Course</h3>

        <div class="table-data">
            <table>
                <tr>
                    <th>Course ID</th>
                    <th>Course Code</th>
                    <th>Course Acronym</th>
                    <th>Course Name</th>
                    <th>Course Department</th>
                    <th>Course Description</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
                <?php 
                $count_row = 1;
                $query = mysqli_query($connect, "SELECT * FROM `course`");
                while($row = mysqli_fetch_assoc($query)){   
                ?>
                <tr>
                    <td> <?php echo $count_row; ?> </td>
                    <td> <?php echo $row['course_code']; ?></td>
                    <td> <?php echo $row['course_acronym']; ?></td>
                    <td> <?php echo $row['course_name']; ?></td>
                    <td> <?php echo $row['department']; ?></td>
                    <td> <?php echo $row['course_description']; ?></td>
                    <td><a href="course.php?update=<?php echo $row['course_id'] ?>"><i class="ri-edit-line"></i></a></td>
                    <td><a href="course.php?deleteID=<?php echo $row['course_id'] ?>"><i class="ri-delete-bin-6-line"></i></a></i></td>
                </tr>
                <?php $count_row++; 
             } ?>
            </table>
        </div>
    </div>


    
</div>



    </div>

</body>
</html>