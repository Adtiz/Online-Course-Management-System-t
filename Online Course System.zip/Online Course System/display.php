<?php
include "connection.php";
session_start();
$user_ID = $_SESSION['user_id'];

if(!isset($user_ID)){
   header('location:login.php');
};


if(isset($_GET['logout'])){
  unset($user_ID);
   session_destroy();
   header('location:login.php');
}

if(isset($_GET['viewID'])){
    $_ID = $_GET['viewID'];
    $query = mysqli_query($connect, "SELECT * FROM `department` WHERE id = '$_ID' ");
    $row = mysqli_fetch_assoc($query);
    $_SESSION['department'] = $row['department_acronym'];
    $_SESSION['Dep_ID'] = $row['id'];
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <link
    href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css"
    rel="stylesheet"
/>
    <title>Department Course</title>
</head>
<body>
    <div class="container-box">
        <nav class="nav-top">
            <a href=""><h3><i class="ri-graduation-cap-fill"></i>OCS</h3></a>
            <div class="title-name">
            <h2> Online Course Management
            System</h2>
            </div>
            <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="logout.php?logout=<?php echo $user_ID ?>">Logout</a></li>
            </ul>
        </nav>

<div class="container row">
    

<div class="table-dep">
    <div class="department-box">
        <?php 
       $_ID = $_SESSION['Dep_ID'];
        $query = mysqli_query($connect, "SELECT * FROM `department` WHERE id = '$_ID'");
        $row = mysqli_fetch_assoc($query);
        ?>
        <?php 
        if($row['department_logo'] == ""):
        ?>
          <img src="dep_logo/default.png" alt=""> 
        <?php else:?>
            <img src="dep_logo/<?php echo $row['department_logo'];?>" alt=""> 
                <?php 
        endif
        ?>
        
        <div class="department-name">
            <h3><?php echo $row['department_acronym'];?></h3>
            <p>
            <?php echo $row['department_name'];?> 
            </p>
        </div>
    </div>

    <div class="table-box" id="table">
    <h3>List</h3>

        <div class="table-data">
            <table>
                <tr>
                    <th>Course ID</th>
                    <th>Course Code</th>
                    <th>Course Acronym</th>
                    <th>Course Name</th>
                    <th>Course Department</th>

                </tr>
                <?php 
                $_count = 1;
                $_Dep = $_SESSION['department'];
                $query = mysqli_query($connect, "SELECT * FROM `course` WHERE department = '$_Dep'");
                while($row= mysqli_fetch_assoc($query)){
                
                ?>
                <tr>
                    <td><?php echo $_count ?></td>
                    <td><?php echo $row['course_code']; ?></td>
                    <td><?php echo $row['course_acronym']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                    <td><?php echo $row['department']; ?></td>
                    
                </tr>
                <?php 
                $_count++;
                }
                ?>

            </table>
            
        </div>


    </div>
</div>
   


    
</div>



    </div>

</body>
</html>
